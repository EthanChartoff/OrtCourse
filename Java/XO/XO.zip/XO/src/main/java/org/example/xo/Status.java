package org.example.xo;

public enum Status {
    SEARCHING,
    ACTIVE,
    INACTIVE
}
