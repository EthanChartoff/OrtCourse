package org.example.xo;

public enum PlayerResult {
    WIN,
    LOSS,
    DRAW,
    NULL
}
