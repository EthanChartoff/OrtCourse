package org.example.xo;

import java.net.Socket;

public abstract class ClientRequest extends Request {}
