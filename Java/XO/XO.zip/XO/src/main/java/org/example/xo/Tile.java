package org.example.xo;

public enum Tile {
    X,
    O,
    EMPTY
}
