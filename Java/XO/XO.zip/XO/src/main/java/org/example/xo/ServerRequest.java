package org.example.xo;

public abstract class ServerRequest extends Request {}
