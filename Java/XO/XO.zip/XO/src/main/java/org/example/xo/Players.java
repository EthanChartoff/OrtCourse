package org.example.xo;

public enum Players {
    PLAYER_X,
    PLAYER_O,
    NON
}
