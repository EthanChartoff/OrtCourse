package org.example.xo;

public enum GameResult {
    X,
    O,
    DRAW,
    NULL
}
