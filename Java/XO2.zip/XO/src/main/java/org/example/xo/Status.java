package org.example.xo;

enum Status {
    SEARCHING,
    ACTIVE,
    INACTIVE
}
