package org.example.xo;

enum Tile {
    X,
    O,
    EMPTY
}
